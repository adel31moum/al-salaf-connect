محاكاة مكالمة واردة - ليلى

الملفات:
- fake_call_app.html: النسخة النهائية مع زر المشاركة
- fake-call-simulator.html: النسخة الأولى

افتح fake_call_app.html في أي متصفح للهاتف للتشغيل الفوري.